var environment = {
    BASE_URL: 'https://localhost:5001',
    EXCEPTIONLESS_API_KEY: '',
    EXCEPTIONLESS_SERVER_URL: '',
    FACEBOOK_APPID: '',
    GITHUB_APPID: '',
    GOOGLE_APPID: '',
    INTERCOM_APPID: '',
    LIVE_APPID: '',
    SLACK_APPID: '',
    STRIPE_PUBLISHABLE_KEY: '',
    SYSTEM_NOTIFICATION_MESSAGE: '',
    USE_HTML5_MODE: false,
    USE_SSL: false,
    ENABLE_ACCOUNT_CREATION: false
};
